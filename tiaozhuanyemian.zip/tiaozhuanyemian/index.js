const Koa = require('koa');
const KoaBody = require('koa-body');
const KoaStatic = require('koa-static');
const Router = require('koa-router');
const fs = require('fs');
const multer =require('koa-multer');
const path = require('path');//处理文件 路径的
const DB=require('./db');


var storage = multer.diskStorage({
    destination: function(req, file, cb) {
      cb(null, './static/uploads/');
    },
    filename: function(req, file, cb) {
        console.log(file);//扩展名
// extname路径当中最后一段文件的扩展名
        console.log(path.extname(file.originalname))//输出格式.jpg
      cb(
        null,
        file.fieldname + '-' + Date.now() + path.extname(file.originalname)
      );
    }
  });
  
  var upload = multer({ storage: storage });
  
  const app = new Koa();
  
//托管静态文件
app.use(KoaStatic('static'));
app.use(KoaBody(
    {multipart:true} //解析请求体  这样KoaBody才能解析这样表单类型
    
));

const router = new Router();
//filename由于该方法属于fs模块，使用前需要引入fs模块（var fs= require(“fs”) ）
//filename    文件路径
//options      option对象，包含 encoding，编码格式，该项是可选的。
router 
    .get('/login',ctx =>{
        ctx.type = 'text/html';//实际上就是一个声明代码
        ctx.body = fs.readFileSync('./static/html/login.html');
    } )
//登入页面
    .post('/login',async ctx =>{
         var { username, password } = ctx.request.body;
        // if(username == 'NY' && password == '1234'){
        //     ctx.body = {code:200,message:'登入成功'};
        // }else{
        //     ctx.body = {code:-1,message:'用户名密码错误'};
        // }
       var ret= await DB('users') 
        .where({
           username, 
           password
        })
        .select('id');
        console.log(ret);

        if(ret && ret.length>0){
            ctx.body={code:200,message:'登入成功',user:{name:username }};
            
        }else{
            ctx.body={code:-1,message:'用户名或密码错误' };
        }
    })
//注册页面
    .get('/register',ctx=>{
        ctx.type = 'text/html';
        ctx.body = fs.readFileSync('./static/html/register.html');
    })
    .post('/register', async ctx => {
        var {username,password,repasswd}=ctx.request.body;

        if(password!==repasswd){
            ctx.body ={code:-2,message:'两次密码不一致'};
            return;
        }
//insert语句用于像表中插入新记录。
        ret = await DB('users').insert({username,password});
          //  console.log(ret); 打印id 返回值是一个数组
          if(ret&&ret.length>0){
              ctx.body = {code:200,message:'注册成功'};
          }else{
              ctx.body = {code:0,message:'网络异常'};
          }

    })
    .get('/',ctx =>{
        ctx.type = 'text/html';
        ctx.body = fs.readFileSync('./static/html/index.html');
    })
    //upload 上传的意思
    .post('/upload', upload.single('file'), ctx => {
        // 做响应
        let filePath = ctx.req.file.path;
        let fileName = path.basename(filePath);
        //console.log(ctx.req.file);
         //console.log(fileName);
        //console.log(ctx.req.file.path);//得到文件上传的位置
        ctx.body = { src: `/uploads/${fileName}` };
      })
    .get('/upload',ctx=>{
        ctx.type = 'text/html';
        ctx.body = fs.readFileSync('./static/html/upload.html');
    });

    app.use(router.routes()).use(router.allowedMethods());//把路由应用进去

    app.listen(8080,'localhost',()=>{
        console.log('Server Started.');
    });

