document.querySelector('form').addEventListener('submit',function(e){
 e.preventDefault();

 var username= this.username.value;
 var password=this.password.value;

 ajax({
    url:'/login',
    type:'post',
    data:{ username, password}
 }).then(res=>{
   console.log(res);
      alert(res.message)//message 原始值
      if(res.code == 200){
        location ='/'; //跳转主页
      }
 });

})